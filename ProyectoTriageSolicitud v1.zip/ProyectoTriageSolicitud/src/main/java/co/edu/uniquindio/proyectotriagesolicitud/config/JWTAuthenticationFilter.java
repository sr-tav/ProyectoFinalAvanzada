package co.edu.uniquindio.proyectotriagesolicitud.config;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class JWTAuthenticationFilter {

}
